<?php

$site_url = 'http://localhost/projects/simplesocial';
$theme_url = $site_url."/theme";

$db_host = 'localhost';
$db_name = 'simplesocial';
$db_username = 'root';
$db_pass = '';
?>