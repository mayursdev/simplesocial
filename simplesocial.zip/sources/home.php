<?php

$so['page']='home';
$so['content']=returnPageContents('home/content');

?>