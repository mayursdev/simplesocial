<?php

$so['page']='settings';
$so['content']=returnPageContents('settings/content');

?>