<?php

$so['page']='login';
$so['content']=returnPageContents('login/content');

?>