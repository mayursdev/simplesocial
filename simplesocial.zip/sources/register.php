<?php

$so['page']='register';
$so['content']=returnPageContents('register/content');

?>